
import 'package:flutter/material.dart';
import 'package:udaasesham/splashScreen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'شامِ  اُداس',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        // Define your theme here
        textTheme: TextTheme(
          bodyLarge: TextStyle(
            fontFamily: "علوی نستعلیق",
          ),
        ),
      ),// Enable system-based theme switching
      home: SplashScreen(),
    );
  }
}
